<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ObatController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::controller(ObatController::class)
    ->prefix('/manajemen_obat') //menu menejemen
    ->group(function(){
        Route::get('/', 'index')->name('obat.index'); //untuk create,delete edit menu di dalam menu//
    });

Route::get('obat/{id}/edit', [ObatController::class, 'edit'])->name('obat.edit');
Route::put('obat/{id}', 'ObatController@update')->name('obat.update');


Route::controller(UserController::class)
    ->prefix('/manajemen_user') //menu menejemen
    ->group(function(){
        Route::get('/', 'index')->name('manajemen_user.index'); //untuk create,delete edit menu di dalam menu//
    });



require __DIR__.'/auth.php';
