{{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> --}}

@extends('layout')
@section('content')
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Manajemen Obat</h1>

                    <div class="card shadow mb-4">
                        {{-- <div class="card-header py-3">
                          <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                          <div class="m-0 card-header py-3 text-right">
                            <button type="submit" class="btn btn-primary">Submit</button>
                          </div>
                        </div> --}}


                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Data Obat</h6>
                            <div>
                                <button type="tambah" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>

                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Nama Obat</th>
                                        <th>Nama Obat</th>
                                        <th>Brand</th>
                                        <th>Stok</th>
                                        <th>Tanggal Kadaluarsa</th>
                                        <th>Harga</th>
                                        <th>Keterangan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($obats as $obat)
                                    <tr>
                                        <td>{{ $obat->nama_obat }}</td>
                                        <td>{{ $obat->id }}</td>
                                        <td>{{ $obat->nama_produsen }}</td>
                                        <td>{{ $obat->stok }}</td>
                                        <td>{{ $obat->tgl_kadaluarsa }}</td>
                                        <td>{{ $obat->harga }}</td>
                                        <td>{{ $obat->Keterangan }}</td>
                                        <td>{{ $obat->user->id }}</td>
                                        <td>
                                            <!-- Edit Button -->
                                            {{-- <button class="btn btn-primary edit-button" data-id={{ $obat->obat_id }}>Edit</button> --}}
                                            <a href="{{ route('obat.edit', ['id' => $obat->id]) }}" class="btn btn-primary">Edit</a>

                                            <!-- Delete Button (you can use a form for a better approach) -->
                                            <form action="#" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                          </div>
                        </div>
                         <!-- Modal -->
                            <<div class="modal" id="editModal" tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div id="modal-content-placeholder"></div>
                                    </div>
                                </div>
                            </div>
                      </div>

                </div>
                <!-- /.container-fluid -->
@endsection
