<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\user;
class UserController extends Controller
{
    public function index(){
        $users = user::all();
        return view('manajemen_user.index',compact('users'));


    }
}
