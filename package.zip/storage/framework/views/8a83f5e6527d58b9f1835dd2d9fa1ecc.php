<?php $__env->startSection('content'); ?>
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Manajemen Obat</h1>

                    <table class = "table table-boarder table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Nama Obat</th>
                                <th>Brand</th>
                                <th>Stok</th>
                                <th>Tanggal Kadaluarsa</th>
                                <th>Harga</th>
                                <th>Keterangan</th>
                                <th>user_id</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($obat->nama_obat); ?></td>
                                <td><?php echo e($obat->nama_produsen); ?></td>
                                <td><?php echo e($obat->stok); ?></td>
                                <td><?php echo e($obat->tgl_kadaluarsa); ?></td>
                                <td><?php echo e($obat->harga); ?></td>
                                <td><?php echo e($obat->Keterangan); ?></td>
                                <td><?php echo e($obat->user->id); ?></td>
                                <td>
                                        <a href="" class="btn btn-success">Edit</a>
                                        <a href="" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>



                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotekghibran\resources\views/manajemen_obat/index.blade.php ENDPATH**/ ?>