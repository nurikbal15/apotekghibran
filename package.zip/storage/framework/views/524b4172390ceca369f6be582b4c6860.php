<?php $__env->startSection('content'); ?>
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Manajemen Obat</h1>

                    <div class="card shadow mb-4">
                        


                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Data Obat</h6>
                            <div>
                                <button type="tambah" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>

                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Nama Obat</th>
                                        <th>Nama Obat</th>
                                        <th>Brand</th>
                                        <th>Stok</th>
                                        <th>Tanggal Kadaluarsa</th>
                                        <th>Harga</th>
                                        <th>Keterangan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($obat->nama_obat); ?></td>
                                        <td><?php echo e($obat->id); ?></td>
                                        <td><?php echo e($obat->nama_produsen); ?></td>
                                        <td><?php echo e($obat->stok); ?></td>
                                        <td><?php echo e($obat->tgl_kadaluarsa); ?></td>
                                        <td><?php echo e($obat->harga); ?></td>
                                        <td><?php echo e($obat->Keterangan); ?></td>
                                        <td><?php echo e($obat->user->id); ?></td>
                                        <td>
                                            <!-- Edit Button -->
                                            
                                            <a href="<?php echo e(route('obat.edit', ['id' => $obat->id])); ?>" class="btn btn-primary">Edit</a>

                                            <!-- Delete Button (you can use a form for a better approach) -->
                                            <form action="#" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                          </div>
                        </div>
                         <!-- Modal -->
                            <<div class="modal" id="editModal" tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div id="modal-content-placeholder"></div>
                                    </div>
                                </div>
                            </div>
                      </div>

                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotekghibran\resources\views/obat/index.blade.php ENDPATH**/ ?>