<?php $__env->startSection('content'); ?>
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">dashboard</h1>







                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotekghibran\resources\views/dashboard.blade.php ENDPATH**/ ?>