<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('obats', function (Blueprint $table) {
            $table->string('id',6)->primary();
            $table->string('nama_obat');
            $table->string('nama_produsen');
            $table->integer('stok');
            $table->date('tgl_kadaluarsa');
            $table->integer('harga');
            $table->string('keterangan');
            $table->timestamps();
            $table->unsignedBigInteger('rak_id');
            $table->unsignedBigInteger('admin_id');
            $table->unsignedBigInteger('user_id');
        });

        Schema::table('obats', function (Blueprint $table){
                $table->foreign('rak_id')->references('id')->on('raks');
            });
        
        Schema::table('obats', function (Blueprint $table){
            $table->foreign('admin_id')->references('id')->on('admins');
        });

        Schema::table('obats', function (Blueprint $table){
            $table->foreign('user_id')->references('id')->on('users');
        });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('obats');
    }
};
